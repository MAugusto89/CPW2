$("#form-valor").maskMoney();

const saveCadastro = (event) => {
    event.preventDefault()

    const name = document.getElementById('form-descricao').value

    const valor = document.getElementById('form-valor').value
    const qtde = document.getElementById('form-estoque').value

    const cadastro = { name, valor, qtde }
    cadastros.push(cadastro)
    storeCadastro()
    printCadastro(cadastro)
    clearForm()
}

const clearForm = () => {
    const cadastroForm = document.getElementById('form-cadastro')
    cadastroForm.reset()
}

const printCadastro = (cadastro) => {
    const { name, valor, qtde } = cadastro

    const cadastroCardValue = `
    <div class='product-card'>
        <div class='product-row'>
            <p>Nome do produto</p><span class='product-name'>${name}</span>
        </div>

        <div class='product-row'>
            <p>Preço</p><span class='product-metadata'>${valor}</span>
        </div>

        <div class='product-row'>
            <p>Em estoque</p><span class='product-metadata'>${qtde}</span>
        </div>
    </div>
  `
    const registroArea = document.getElementById('produtosArea')
    registroArea.insertAdjacentHTML('afterbegin', cadastroCardValue)
}

const storeCadastro = () => {
    const cadastroJson = JSON.stringify(cadastros)
    localStorage.setItem('cadastros', cadastroJson)
}

const cadastroJson = localStorage.getItem('cadastros')
const cadastros = cadastroJson ? JSON.parse(cadastroJson) : []
for (let i = 0; i < cadastros.length; i++) {
    printCadastro(cadastros[i])
}
